How to run:

python hmm.py

or to read to file:

python hmm.py > results.txt
