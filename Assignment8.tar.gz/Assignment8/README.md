How to run:

python hmm.py

or to write to file:

python hmm.py > results.txt
